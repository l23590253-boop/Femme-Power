package com.example.femmepower;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Mensajes extends AppCompatActivity {

    EditText mensajeEdit;
    Switch switchGPS, switchRitmo;
    Button btnGuardar;
    private Button btninicio, btncontactos, btnmensaje, btnperfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mensajes);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 🔗 NAV
        btninicio = findViewById(R.id.btninicio);
        btncontactos = findViewById(R.id.btncontactos);
        btnmensaje = findViewById(R.id.btnmensaje);
        btnperfil = findViewById(R.id.btnperfil);

        seleccionar(btnmensaje);

        btncontactos.setOnClickListener(v -> {
            startActivity(new Intent(Mensajes.this, Contacto.class));
        });

        btninicio.setOnClickListener(v -> {
            startActivity(new Intent(Mensajes.this, Principal.class));
        });

        // 🔗 CAMPOS
        mensajeEdit = findViewById(R.id.sms);
        switchGPS = findViewById(R.id.gps);
        //switchRitmo = findViewById(R.id.ritmo_c);
        btnGuardar = findViewById(R.id.button);

        // 📥 RECUPERAR
        SharedPreferences prefs = getSharedPreferences("femme_power", MODE_PRIVATE);

        mensajeEdit.setText(prefs.getString("mensaje", ""));
        switchGPS.setChecked(prefs.getBoolean("gps", false));
        //switchRitmo.setChecked(prefs.getBoolean("ritmo", false));

        // 💾 GUARDAR
        btnGuardar.setOnClickListener(view -> {

            String mensaje = mensajeEdit.getText().toString();

            if (mensaje.isEmpty()) {
                Toast.makeText(this, "Escribe un mensaje", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("mensaje", mensaje);
            editor.putBoolean("gps", switchGPS.isChecked());
            //editor.putBoolean("ritmo", switchRitmo.isChecked());
            editor.apply();

            Toast.makeText(this, "Guardado correctamente", Toast.LENGTH_SHORT).show();
        });
    }

    private void seleccionar(Button activo) {
        btninicio.setBackground(getDrawable(R.drawable.inactivo));
        btncontactos.setBackground(getDrawable(R.drawable.inactivo));
        btnmensaje.setBackground(getDrawable(R.drawable.inactivo));
        btnperfil.setBackground(getDrawable(R.drawable.inactivo));

        activo.setBackground(getDrawable(R.drawable.activo));
    }
}