package com.example.femmepower;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Contacto extends AppCompatActivity {

    private Button btninicio, btncontactos, btnmensaje, btnperfil;

    RecyclerView recyclerView;
    Button btnAgregar;

    ArrayList<ContactoModelo> lista;
    ContactoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.Contactos);
        btnAgregar = findViewById(R.id.btnAgregar);

        lista = new ArrayList<>();
        adapter = new ContactoAdapter(lista);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnAgregar.setOnClickListener(v -> abrirContactos());

        //
        btninicio    = findViewById(R.id.btninicio);
        btncontactos = findViewById(R.id.btncontactos);
        btnmensaje   = findViewById(R.id.btnmensaje);
        btnperfil    = findViewById(R.id.btnperfil);

        // Botón activo por defecto en esta pantalla
        seleccionar(btncontactos);

        btninicio.setOnClickListener(v -> {
            startActivity(new Intent(Contacto.this, Principal.class));
        });
        btncontactos.setOnClickListener(v -> {
            seleccionar(btncontactos);
        });
        btnmensaje.setOnClickListener(v -> {
            seleccionar(btnmensaje);
            startActivity(new Intent(Contacto.this, Mensajes.class));
        });
        btnperfil.setOnClickListener(v -> {
            seleccionar(btnperfil);
            startActivity(new Intent(Contacto.this, Inicio.class));
        });
    }

    private void abrirContactos() {
        Intent intent = new Intent(
                Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        );
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                int nombreIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int numeroIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

                String nombre = cursor.getString(nombreIndex);
                String numero = cursor.getString(numeroIndex);

                lista.add(new ContactoModelo(nombre, numero));
                adapter.notifyItemInserted(lista.size() - 1);

                cursor.close();
            }
        }
    }

    private void seleccionar(Button activo) {
        btninicio.setBackground(getDrawable(R.drawable.inactivo));
        btncontactos.setBackground(getDrawable(R.drawable.inactivo));
        btnmensaje.setBackground(getDrawable(R.drawable.inactivo));
        btnperfil.setBackground(getDrawable(R.drawable.inactivo));

        btninicio.setTextColor(getColor(R.color.morado1));
        btncontactos.setTextColor(getColor(R.color.morado1));
        btnmensaje.setTextColor(getColor(R.color.morado1));
        btnperfil.setTextColor(getColor(R.color.morado1));

        activo.setBackground(getDrawable(R.drawable.activo));
        activo.setTextColor(getColor(R.color.morado2));
    }
}