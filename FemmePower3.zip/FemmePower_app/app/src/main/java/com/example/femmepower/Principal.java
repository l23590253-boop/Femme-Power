package com.example.femmepower;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Principal extends AppCompatActivity {

    //botones que se utilizaran
    private Button btninicio, btncontactos, btnmensaje, btnperfil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btninicio = findViewById(R.id.btninicio);
        btncontactos = findViewById(R.id.btncontactos);
        btnmensaje = findViewById(R.id.btnmensaje);
        btnperfil = findViewById(R.id.btnperfil);

        // Botón activo por defecto
        seleccionar(btninicio);

        //contactos
        btncontactos.setOnClickListener(v -> {
            seleccionar(btncontactos);
            Intent intent = new Intent(Principal.this, Contacto.class);
            startActivity(intent);
        });
        //mensaje
        btnmensaje.setOnClickListener(v -> {
            seleccionar(btnmensaje);
            Intent intent = new Intent(Principal.this, Mensajes.class);
            startActivity(intent);
        });
        //perfil
        btnperfil.setOnClickListener(v -> {
            seleccionar(btnperfil);
            Intent intent = new Intent(Principal.this, Inicio.class);
            startActivity(intent);
        });
    }

//Para activar el boton de la pantalla seleccionada
     private void seleccionar(Button activo) {
        // Reset todos a inactivo
        btninicio.setBackground(getDrawable(R.drawable.inactivo));
        btncontactos.setBackground(getDrawable(R.drawable.inactivo));
        btnmensaje.setBackground(getDrawable(R.drawable.inactivo));
        btnperfil.setBackground(getDrawable(R.drawable.inactivo));

        // Reset color texto
        btninicio.setTextColor(getColor(R.color.morado1));
        btncontactos.setTextColor(getColor(R.color.morado1));
        btnmensaje.setTextColor(getColor(R.color.morado1));
        btnperfil.setTextColor(getColor(R.color.morado1));

        // Activar el seleccionado
        activo.setBackground(getDrawable(R.drawable.activo));
        activo.setTextColor(getColor(R.color.morado2)); // <- color de texto
    }
}